from SimpleOrthanc import Orthanc
orthanc = Orthanc(username='marcel', password='pyorthanc!')